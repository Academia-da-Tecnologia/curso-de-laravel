<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Registro no site do curso de laravel</title>
    <body>
      
      <div id="container">
          <h2>Registro no portal de notícias do curso de laravel</h2>
          <p class="text-success">Mensagem Enviada dia: {{ $data }}</p>
          <p class="text-success">Mensagem Enviada por: {{ $email }}</p>
          <p>Se não foi você que se cadastrou no site, por favor desconsidere esse email.</p>
      </div>     

    </body>
</html>