<?php

require 'routeAdmin.php';
require 'routeSite.php';