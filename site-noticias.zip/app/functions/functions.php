<?php

function oddEven( $contagem ){
    if( $contagem % 2 == 0 ){
        return 'even';
    }
    return 'odd';
}