<?php

namespace app\models\site;

class AttributesValidateModel extends \Eloquent{

  protected $table = 'tb_attributes_validate';
  protected $guarded = array();

}