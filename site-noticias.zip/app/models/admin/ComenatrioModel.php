<?php

namespace app\models\admin;

class ComentarioModel extends \Eloquent{

    protected $table = 'tb_comentarios';
    protected $guarded = [];
    public $timestamps = false;

}